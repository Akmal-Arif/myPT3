huruf = str(input("Masukkan huruf anda : "))
if huruf in ("a","e","i","o","u"):
  print ("Huruf vokal")
else:
  print("Huruf konsonan")